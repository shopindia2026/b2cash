// Cloud Functions for B2 CASH. All coin/point writes happen here, never in the browser.
const { onCall, HttpsError } = require("firebase-functions/v2/https");
const { initializeApp } = require("firebase-admin/app");
const { getFirestore, FieldValue } = require("firebase-admin/firestore");

initializeApp();
const db = getFirestore();

// Set with: firebase functions:secrets:set ADMIN_EMAIL  (or an env var in the console)
const ADMIN_EMAIL = process.env.ADMIN_EMAIL || "";
const MAX_ACTIVE_GAMES = 20;
const DAY_MS = 24 * 60 * 60 * 1000;
const SCORE_COOLDOWN_MS = 5000;
const DEFAULTS = { dailyReward: 50, coinsPerWin: 5, maxScorePerSubmit: 10 };

function requireUser(req) {
  if (!req.auth) throw new HttpsError("unauthenticated", "Please log in first.");
  return req.auth.uid;
}
function requireAdmin(req) {
  const t = req.auth && req.auth.token;
  if (!t || t.admin !== true || !ADMIN_EMAIL || t.email !== ADMIN_EMAIL || t.email_verified !== true) {
    throw new HttpsError("permission-denied", "Admin access only.");
  }
}
async function rewardConfig() {
  const s = await db.doc("config/rewards").get();
  return { ...DEFAULTS, ...(s.exists ? s.data() : {}) };
}

// Daily login reward: once per 24h, enforced inside a transaction.
exports.claimDailyReward = onCall(async (req) => {
  const uid = requireUser(req);
  const cfg = await rewardConfig();
  const ref = db.doc(`users/${uid}`);
  return db.runTransaction(async (t) => {
    const snap = await t.get(ref);
    if (!snap.exists) throw new HttpsError("not-found", "Profile not found.");
    if (snap.data().blocked) throw new HttpsError("permission-denied", "Account blocked.");
    const last = snap.data().lastRewardAt ? snap.data().lastRewardAt.toMillis() : 0;
    if (Date.now() - last < DAY_MS) throw new HttpsError("failed-precondition", "Come back tomorrow for your next reward.");
    t.update(ref, { coins: FieldValue.increment(cfg.dailyReward), lastRewardAt: FieldValue.serverTimestamp() });
    return { reward: cfg.dailyReward };
  });
});

// Score submission: game must be enabled, score bounded, cooldown enforced, recorded server-side.
exports.submitScore = onCall(async (req) => {
  const uid = requireUser(req);
  const { gameId, score } = req.data || {};
  if (typeof gameId !== "string" || !/^[a-z0-9_-]{1,40}$/.test(gameId)) throw new HttpsError("invalid-argument", "Unknown game.");
  if (!Number.isInteger(score) || score < 0) throw new HttpsError("invalid-argument", "Invalid score.");
  const cfg = await rewardConfig();
  const gameSnap = await db.doc(`games/${gameId}`).get();
  if (!gameSnap.exists || gameSnap.data().enabled !== true) throw new HttpsError("failed-precondition", "This game is not active.");
  const game = gameSnap.data();
  const maxScore = Number(game.maxScore) || cfg.maxScorePerSubmit;
  if (score > maxScore) throw new HttpsError("invalid-argument", "Score is outside the allowed range.");

  const userRef = db.doc(`users/${uid}`);
  const pts = score;
  const coins = score > 0 ? cfg.coinsPerWin : 0;
  await db.runTransaction(async (t) => {
    const u = await t.get(userRef);
    if (!u.exists) throw new HttpsError("not-found", "Profile not found.");
    if (u.data().blocked) throw new HttpsError("permission-denied", "Account blocked.");
    const last = u.data().lastScoreAt ? u.data().lastScoreAt.toMillis() : 0;
    if (Date.now() - last < SCORE_COOLDOWN_MS) throw new HttpsError("resource-exhausted", "Slow down a little.");
    t.update(userRef, {
      points: FieldValue.increment(pts), coins: FieldValue.increment(coins), lastScoreAt: FieldValue.serverTimestamp()
    });
    t.set(db.collection("gameHistory").doc(), {
      uid, gameId, gameName: game.name || gameId, points: pts, coins, playedAt: FieldValue.serverTimestamp()
    });
  });
  return { points: pts, coins };
});

// Admin: enable/disable a game. Enabling is refused when 20 games are already live.
exports.setGameEnabled = onCall(async (req) => {
  requireAdmin(req);
  const { gameId, enabled } = req.data || {};
  if (typeof gameId !== "string" || typeof enabled !== "boolean") throw new HttpsError("invalid-argument", "Bad input.");
  return db.runTransaction(async (t) => {
    const ref = db.doc(`games/${gameId}`);
    const target = await t.get(ref);
    if (!target.exists) throw new HttpsError("not-found", "Game not found.");
    if (enabled && target.data().enabled !== true) {
      const live = await t.get(db.collection("games").where("enabled", "==", true).limit(MAX_ACTIVE_GAMES));
      if (live.size >= MAX_ACTIVE_GAMES) throw new HttpsError("failed-precondition", `Only ${MAX_ACTIVE_GAMES} games can be active.`);
    }
    t.update(ref, { enabled });
    t.set(db.collection("securityLogs").doc(), { action: "setGameEnabled", gameId, enabled, at: FieldValue.serverTimestamp() });
    return { gameId, enabled };
  });
});

// Admin: block or unblock a user.
exports.setUserBlocked = onCall(async (req) => {
  requireAdmin(req);
  const { uid, blocked } = req.data || {};
  if (typeof uid !== "string" || typeof blocked !== "boolean") throw new HttpsError("invalid-argument", "Bad input.");
  await db.doc(`users/${uid}`).update({ blocked });
  await db.collection("securityLogs").add({ action: "setUserBlocked", uid, blocked, at: FieldValue.serverTimestamp() });
  return { uid, blocked };
});
