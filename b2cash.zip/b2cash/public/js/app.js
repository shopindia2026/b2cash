// B2 CASH client. Coins and points are NEVER written from the browser:
// the rules block it and Cloud Functions do all reward and score writes.
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
import {
  getAuth, onAuthStateChanged, createUserWithEmailAndPassword,
  signInWithEmailAndPassword, signOut, updateProfile
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";
import {
  getFirestore, doc, setDoc, getDoc, onSnapshot, collection, query,
  where, orderBy, limit, addDoc, serverTimestamp
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";
import { getFunctions, httpsCallable } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-functions.js";

// Firebase web config is read from <script id="firebase-config"> in index.html (public by design).
const firebaseConfig = JSON.parse(document.getElementById("firebase-config").textContent);

const MAX_ACTIVE_GAMES = 20;
// Only games with a working build are shown, even if an admin enables more in Firestore.
const BUILT_GAMES = new Set(["tictactoe"]);

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);
const fns = getFunctions(app);
const $ = (s, root = document) => root.querySelector(s);
const esc = (t) => String(t ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const notice = (msg, ms = 3500) => { const n = $("#notice"); n.textContent = msg; n.hidden = false; setTimeout(() => n.hidden = true, ms); };

let user = null, profile = null, games = [], siteCfg = { maintenance: false };

// ---------- routing ----------
function route() {
  const id = (location.hash || "#home").slice(1).split("?")[0];
  const page = document.getElementById(id) || document.getElementById("home");
  if (page.hasAttribute("data-requires-auth") && !user) { location.hash = "#login"; return; }
  document.querySelectorAll("[data-page]").forEach(p => p.classList.toggle("active", p === page));
  document.querySelectorAll(".nav a, .bottombar a").forEach(a => a.toggleAttribute("aria-current", a.getAttribute("href") === "#" + page.id));
  document.querySelectorAll("[data-auth]").forEach(a => a.hidden = !user);
  document.querySelectorAll("[data-guest]").forEach(a => a.hidden = !!user);
  if (page.id === "game") renderGameDetail(); 
  window.scrollTo(0, 0);
}
window.addEventListener("hashchange", route);

// ---------- site config (maintenance) ----------
onSnapshot(doc(db, "config", "site"), s => {
  siteCfg = s.exists() ? s.data() : siteCfg;
  $("#maintenance").hidden = !siteCfg.maintenance;
}, () => {});

// ---------- games ----------
onSnapshot(query(collection(db, "games"), where("enabled", "==", true), limit(MAX_ACTIVE_GAMES)), snap => {
  games = snap.docs.map(d => ({ id: d.id, ...d.data() }))
    .filter(g => BUILT_GAMES.has(g.id))
    .slice(0, MAX_ACTIVE_GAMES);
  renderGames();
  renderGameDetail();
}, err => notice("Could not load games: " + err.message));

function tileHTML(g) {
  return `<a class="tile" href="#game?id=${esc(g.id)}"><span class="glyph" aria-hidden="true">${esc(g.icon || "🎮")}</span>
    <strong>${esc(g.name)}</strong><small>${esc(g.description || "Free to play")}</small></a>`;
}
function renderGames() {
  $("#homeGames").innerHTML = games.slice(0, 4).map(tileHTML).join("") || `<p class="muted">No games are live yet.</p>`;
  $("#allGames").innerHTML = games.map(tileHTML).join("") || `<p class="muted">No games are live right now. Check back soon.</p>`;
  $("#gameCount").textContent = `${games.length} of ${MAX_ACTIVE_GAMES} games live`;
}

// ---------- game detail + Tic Tac Toe ----------
let ttt = null;
function renderGameDetail() {
  const id = new URLSearchParams((location.hash.split("?")[1]) || "").get("id");
  const el = $("#gameDetail");
  if (!el || location.hash.split("?")[0] !== "#game") return;
  const g = games.find(x => x.id === id);
  if (!g) { el.innerHTML = `<p class="muted">Loading game…</p>`; return; }
  if (g.id === "tictactoe") {
    el.innerHTML = `<div class="game-wrap panel" style="max-width:520px;margin:auto">
      <h2>${esc(g.name)}</h2><p class="muted">You are gold (X). Beat the computer to earn points.</p>
      <div class="status" id="ttStatus" aria-live="polite"></div>
      <div class="board" id="ttBoard"></div>
      <button class="btn ghost" id="ttReset" type="button">New game</button></div>`;
    ttt = { b: Array(9).fill(""), over: false };
    drawTTT();
    $("#ttReset").onclick = () => { ttt = { b: Array(9).fill(""), over: false }; drawTTT(); };
  }
}
const WIN = [[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]];
const winner = b => { for (const [a,c,d] of WIN) if (b[a] && b[a] === b[c] && b[a] === b[d]) return b[a]; return b.includes("") ? null : "draw"; };
function drawTTT() {
  const board = $("#ttBoard"); if (!board || !ttt) return;
  board.innerHTML = ttt.b.map((v, i) => `<button class="cell ${v.toLowerCase()}" data-i="${i}" aria-label="Cell ${i+1} ${v || "empty"}">${v}</button>`).join("");
  board.querySelectorAll(".cell").forEach(c => c.onclick = () => play(+c.dataset.i));
  const w = winner(ttt.b);
  if (w) { ttt.over = true; $("#ttStatus").textContent = w === "draw" ? "Draw" : w === "X" ? "You win!" : "Computer wins"; }
  else $("#ttStatus").textContent = "Your move";
}
function play(i) {
  if (!ttt || ttt.over || ttt.b[i]) return;
  ttt.b[i] = "X"; drawTTT(); if (ttt.over) return finish();
  setTimeout(() => {
    const pick = bestMove(ttt.b);
    ttt.b[pick] = "O"; drawTTT(); if (ttt.over) finish();
  }, 280);
}
// Simple but unbeatable computer: win > block > center > corner > side.
function bestMove(b) {
  const free = b.map((v, i) => v ? -1 : i).filter(i => i >= 0);
  for (const p of ["O", "X"]) for (const i of free) {
    const t = [...b]; t[i] = p; if (winner(t) === p) return i;
  }
  return [4, 0, 2, 6, 8, 1, 3, 5, 7].find(i => !b[i]);
}
async function finish() {
  const w = winner(ttt.b);
  if (w !== "X") return; // only wins are scored
  if (!user) return notice("Log in to save your points.");
  try {
    const res = await httpsCallable(fns, "submitScore")({ gameId: "tictactoe", score: 10 });
    notice(`+${res.data.points} points`);
  } catch (e) { notice(e.message || "Score could not be saved."); }
}

// ---------- auth ----------
const authForm = $("#authForm");
function setRegMode(on) { $("#registerBtn").dataset.mode = on ? "1" : ""; authForm.querySelector(".reg-only").hidden = !on; $("#loginBtn").hidden = on; $("#registerBtn").textContent = on ? "Create account" : "Register"; }
$("#registerBtn").onclick = () => {
  if (!$("#registerBtn").dataset.mode) return setRegMode(true);
  submitAuth(true);
};
authForm.onsubmit = e => { e.preventDefault(); submitAuth(false); };

function validate(fd, reg) {
  const email = (fd.get("email") || "").trim();
  const pass = fd.get("password") || "";
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return "Enter a valid email address.";
  if (pass.length < 8) return "Password must be at least 8 characters.";
  if (reg) {
    const u = (fd.get("username") || "").trim();
    if (!/^[A-Za-z0-9_]{3,20}$/.test(u)) return "Username: 3–20 letters, numbers or underscores.";
  }
  return null;
}
async function submitAuth(reg) {
  const fd = new FormData(authForm);
  const err = validate(fd, reg);
  $("#authError").textContent = err || "";
  if (err) return;
  const btn = reg ? $("#registerBtn") : $("#loginBtn");
  btn.disabled = true;
  try {
    if (reg) {
      const cred = await createUserWithEmailAndPassword(auth, fd.get("email").trim(), fd.get("password"));
      const username = fd.get("username").trim();
      await updateProfile(cred.user, { displayName: username });
      await setDoc(doc(db, "users", cred.user.uid), {
        username, coins: 0, points: 0, blocked: false, createdAt: serverTimestamp()
      });
    } else {
      await signInWithEmailAndPassword(auth, fd.get("email").trim(), fd.get("password"));
    }
    authForm.reset(); setRegMode(false); location.hash = "#dashboard";
  } catch (e) {
    $("#authError").textContent = friendly(e.code);
  } finally { btn.disabled = false; }
}
function friendly(code = "") {
  return ({
    "auth/email-already-in-use": "That email already has an account. Try logging in.",
    "auth/invalid-credential": "Email or password is incorrect.",
    "auth/too-many-requests": "Too many attempts. Wait a few minutes and try again.",
    "auth/network-request-failed": "Network error. Check your connection."
  })[code] || "Something went wrong. Please try again.";
}
$("#logoutBtn").onclick = () => signOut(auth);

onAuthStateChanged(auth, async u => {
  user = u;
  profile = null;
  if (u) {
    const snap = await getDoc(doc(db, "users", u.uid));
    if (!snap.exists()) { await signOut(auth); return notice("Your profile is missing. Please register again."); }
    if (snap.data().blocked) { await signOut(auth); return notice("This account has been blocked. Contact support."); }
    listenProfile(u.uid);
    listenHistory(u.uid);
  }
  $("#account").innerHTML = u
    ? `<a class="pill" href="#dashboard">● ${esc(u.displayName || "Player")}</a>`
    : `<a class="pill" href="#login">Log in</a>`;
  route();
});

// ---------- profile, dashboard, history, leaderboard ----------
function listenProfile(uid) {
  onSnapshot(doc(db, "users", uid), s => {
    if (!s.exists()) return;
    profile = s.data();
    $("#statCoins").textContent = profile.coins ?? 0;
    $("#statPoints").textContent = profile.points ?? 0;
    $("#profileLine").textContent = `Username: ${profile.username || "—"}`;
    $("#uidLine").textContent = uid;
  });
}
function listenHistory(uid) {
  onSnapshot(query(collection(db, "gameHistory"), where("uid", "==", uid), orderBy("playedAt", "desc"), limit(10)),
    snap => {
      $("#history").innerHTML = snap.docs.map(d => {
        const h = d.data();
        return `<li><span>${esc(h.gameName || h.gameId)}</span><span class="muted">+${Number(h.points) || 0} pts</span></li>`;
      }).join("") || `<li class="muted">No games played yet.</li>`;
    }, () => { $("#history").innerHTML = `<li class="muted">History unavailable right now.</li>`; });
}
onSnapshot(query(collection(db, "users"), orderBy("points", "desc"), limit(20)), snap => {
  const rows = snap.docs.map(d => ({ uid: d.id, ...d.data() }));
  $("#rankList").innerHTML = rows.map((r, i) =>
    `<li><span>${i + 1}. ${esc(r.username || "Player")}</span><span class="pts">${Number(r.points) || 0}</span></li>`).join("")
    || `<li class="muted">No players yet.</li>`;
  const me = rows.findIndex(r => user && r.uid === user.uid);
  $("#statRank").textContent = me >= 0 ? `#${me + 1}` : "–";
}, () => { $("#rankList").innerHTML = `<li class="muted">Leaderboard unavailable right now.</li>`; });

$("#claimBtn").onclick = async () => {
  const btn = $("#claimBtn"); btn.disabled = true;
  try {
    const r = await httpsCallable(fns, "claimDailyReward")();
    notice(`+${r.data.reward} coins claimed`);
  } catch (e) { notice(e.message || "Reward unavailable right now."); }
  finally { btn.disabled = false; }
};

// ---------- support ----------
$("#supportForm").onsubmit = async e => {
  e.preventDefault();
  const fd = new FormData(e.target);
  const email = (fd.get("email") || "").trim(), msg = (fd.get("message") || "").trim();
  const err = !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) ? "Enter a valid email." : msg.length < 10 ? "Message must be at least 10 characters." : "";
  $("#supportMsg").textContent = err;
  if (err) return;
  try {
    await addDoc(collection(db, "supportMessages"), { email, message: msg, uid: user?.uid || null, createdAt: serverTimestamp(), status: "open" });
    e.target.reset(); notice("Message sent. We will reply by email.");
  } catch { $("#supportMsg").textContent = "Could not send. Please try again."; }
};

setRegMode(false);
route();
if ("serviceWorker" in navigator) navigator.serviceWorker.register("/sw.js");
