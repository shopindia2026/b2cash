// Admin UI. Convenience only: every action is re-checked by Cloud Functions and Firestore rules.
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
import {
  getAuth, onAuthStateChanged, signInWithEmailAndPassword, signOut, sendPasswordResetEmail
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";
import { getFirestore, collection, getDocs, query, where, limit, onSnapshot } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";
import { getFunctions, httpsCallable } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-functions.js";

const firebaseConfig = JSON.parse(document.getElementById("firebase-config").textContent);
const app = initializeApp(firebaseConfig);
const auth = getAuth(app), db = getFirestore(app), fns = getFunctions(app);

const $ = s => document.querySelector(s);
const esc = t => String(t ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const isGmail = e => /^[^\s@]+@gmail\.com$/i.test(e);

$("#adminForm").onsubmit = async e => {
  e.preventDefault();
  const fd = new FormData(e.target);
  const email = String(fd.get("email")).trim();
  $("#adminErr").textContent = "";
  if (!isGmail(email)) return $("#adminErr").textContent = "Gmail address daalein (name@gmail.com).";
  try { await signInWithEmailAndPassword(auth, email, String(fd.get("password"))); }
  catch { $("#adminErr").textContent = "Login fail. Email ya password galat hai."; }
};

$("#resetBtn").onclick = async () => {
  const email = String(new FormData($("#adminForm")).get("email") || "").trim();
  $("#resetMsg").textContent = "";
  if (!isGmail(email)) return $("#resetMsg").textContent = "Pehle upar admin Gmail likhein.";
  try {
    await sendPasswordResetEmail(auth, email);
    $("#resetMsg").textContent = "Link bhej diya gaya. Gmail check karein (spam bhi dekhein).";
  } catch {
    $("#resetMsg").textContent = "Link nahi bheja ja saka. Firebase config aur email check karein.";
  }
};

$("#adminOut").onclick = () => signOut(auth);

onAuthStateChanged(auth, async u => {
  if (!u) { $("#adminLogin").hidden = false; $("#adminPanel").hidden = true; return; }
  const claims = (await u.getIdTokenResult(true)).claims;
  if (claims.admin !== true) {
    await signOut(auth);
    $("#adminErr").textContent = "Ye account admin ke liye authorized nahi hai.";
    return;
  }
  $("#adminLogin").hidden = true; $("#adminPanel").hidden = false;
  loadDashboard();
});

function loadDashboard() {
  onSnapshot(collection(db, "users"), s => $("#sUsers").textContent = s.size);
  onSnapshot(query(collection(db, "games"), where("enabled", "==", true)), s => $("#sGames").textContent = s.size);
  onSnapshot(query(collection(db, "supportMessages"), where("status", "==", "open"), limit(50)), s => {
    $("#sSupport").textContent = s.size;
    $("#supportList").innerHTML = s.docs.map(d => {
      const m = d.data();
      return `<li><span>${esc(m.email)}: ${esc(m.message)}</span></li>`;
    }).join("") || `<li class="muted">No open messages.</li>`;
  });
  getDocs(collection(db, "games")).then(s => {
    $("#gameAdmin").innerHTML = s.docs.map(d => `
      <li><span>${esc(d.data().name || d.id)}</span>
      <button class="btn ghost" data-game="${esc(d.id)}" data-on="${d.data().enabled === true}">${d.data().enabled === true ? "Disable" : "Enable"}</button></li>`).join("");
    document.querySelectorAll("[data-game]").forEach(b => b.onclick = async () => {
      const enable = b.dataset.on !== "true";
      b.disabled = true;
      try {
        await httpsCallable(fns, "setGameEnabled")({ gameId: b.dataset.game, enabled: enable });
        loadDashboard();
      } catch (err) { alert(err.message); b.disabled = false; }
    });
  });
}

document.querySelectorAll("#blockForm button").forEach(btn => btn.addEventListener("click", async e => {
  e.preventDefault();
  const uid = String(new FormData($("#blockForm")).get("uid") || "").trim();
  if (!/^[A-Za-z0-9]{1,128}$/.test(uid)) return $("#blockMsg").textContent = "Valid UID daalein.";
  try {
    await httpsCallable(fns, "setUserBlocked")({ uid, blocked: btn.value === "true" });
    $("#blockMsg").textContent = `Done: ${btn.value === "true" ? "blocked" : "unblocked"} ${uid}`;
  } catch (err) { $("#blockMsg").textContent = err.message; }
}));
